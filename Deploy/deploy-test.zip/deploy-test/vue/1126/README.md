git 올리기 전에 아래 사항 확인
pip freeze > requirements.txt

pip install -r requirements.txt


