from django.apps import AppConfig


class DiariesConfig(AppConfig):
    name = 'diaries'
